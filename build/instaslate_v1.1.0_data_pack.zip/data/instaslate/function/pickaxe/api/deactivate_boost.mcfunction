function instaslate:pickaxe/api/scan_inventory
advancement revoke @s[predicate=instaslate:boost_valid] only instaslate:deactivate_boost
tell @s[tag=instaslate.debug] deactivate
